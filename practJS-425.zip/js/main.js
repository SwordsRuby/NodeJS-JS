let price = Number(prompt('укажите стоимость товара: '));
let money = Number(prompt('сумма ваших денег: '));

if (isNaN(Number(money)) || isNaN(Number(price))) {
    alert('неверный формат числа');
}
else if (price < 0 || money < 0) {
    alert('числа меньше нуля');
} else if (money > price) {
    alert('ваша сдача: ' + (money - price).toString());
} else if (money < price) {
    alert('Нехватает денег: ' + (price - money).toString());
} else {
    alert('покупка совершенна');
}

let number = parseInt(prompt('введите число: '));
if (number < 0) {
    alert('Меньше нуля');
}
else if (number > 0) {
    alert('Больше нуля');
}
else {
    alert('число равно 0');
}

let a = 3;
let b = 67;
let result;
a + b < 4 ? result = 'Мало' : result = 'Много';
console.log(result)



//pr 2
function printNumbers(a, b) {
    if (a < b) {
        for (let number = a; number <= b; number++) {
            if (number % 2 === 0) {
                console.log(number);
            }
        }
    } else {
        for (let number = b; number <= a; number++) {
            if (number % 2 === 0) {
                console.log(number);
            }
        }
    }
}

a = parseInt(prompt("Введите значение a: "));
b = parseInt(prompt("Введите значение b: "));
printNumbers(a, b);

function min(a, b) {
    console.log("Меньшее число: ", a < b ? a : b);
}

const num1 = parseInt(prompt("Введите первое число: "));
const num2 = parseInt(prompt("Введите второе число: "));
min(num1, num2);

let styles = ["Джаз", "Блюз"];
console.log(styles);

styles.push("Рок-н-ролл");
console.log(styles);

styles[Math.floor(styles.length / 2)] = "Классика";
console.log(styles);

console.log("Удалённый элемент:", styles.shift());
console.log(styles);

styles.unshift("Рэп", "Регги");
console.log(styles);



//pr 3
function btnName(el) {
    el.textContent = 'Вы нажали на меня!';
}

window.addEventListener('mousemove', (event) => {
    const rect = document.querySelector('#rectangle');

    rect.style.left = event.clientX - 25 + 'px';
    rect.style.top = event.clientY - 25 + 'px';
})