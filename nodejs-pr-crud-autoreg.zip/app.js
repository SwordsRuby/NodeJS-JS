require('dotenv').config()
const express = require('express')
const session = require('express-session')
const fileUpload = require('express-fileupload')
const path = require('path')
const ejs = require('ejs')
const mysql = require('mysql2/promise')
const cors = require('cors')
const bcrypt = require('bcryptjs')
const validator = require('validator')
const fs = require('fs')
const app = express()

app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, 'public/ejs'))
app.use(express.json())
app.use(express.urlencoded({ extended: false }))
app.use(express.static('public'))
app.use(cors())
app.use(session({
  secret: 'your-secret-key',
  resave: false,
  saveUninitialized: true,
  cookie: {secure: false}
}))
app.use((req, res, next) => {
  res.locals.session = req.session
  next()
})
app.use(fileUpload())

const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'root',
  database: 'test_nodejs'
})


app.get('/', async (req, res) => {
  const connection = await pool.getConnection()
  const [products] = await connection.execute('SELECT * FROM product')
  connection.release()
  res.render('index', {products: products})
})
app.get('/auth', (req, res) => {
  res.render('auth')
})
app.get('/add', (req, res) => {
  res.render('add')
})
app.get('/reg', (req, res) => {
  res.render('reg')
})
app.get('/logout', (req, res) => {
  req.session.destroy()
  res.redirect('/')
})
app.get('/update', async (req, res) => {
  const {update_id} = req.query
  const connection = await pool.getConnection()
  const [products] = await connection.execute('SELECT * FROM product WHERE id = ?', [update_id])
  const product = products[0]
  connection.release()
  res.render('update', {product: product, title: undefined, price: undefined})
})

app.post('/auth', async (req, res, next) => {
  let err = null
  const {email, password} = req.body
  if (!email || !password) {
    err = 'email or password empty'
    return res.render('auth', {error: err, email:email, password:password})
  }
  else if (password.length < 6) {
    err = 'password less then 6 symbols'
    return res.render('auth', {error:err, email:email, password:password})
  }
  else {
    const connection = await pool.getConnection()
    const [users] = await connection.execute('SELECT * FROM users WHERE email = ?', [email])
        connection.release()
    if (users.length == 0) {
        err = 'user or password is not exists'
       return res.render('auth', {error:err, email:email, password:password})
    }else {
      user = users[0]
      passwordVerify = await bcrypt.compare(password, user.password)
      if (!passwordVerify) {
          err = 'user or password is not exists'
          return res.render('auth', {error:err, email:email, password:password})
      }else {
        req.session.userId = user.id
      err = 'authorization succesfully'
      return res.redirect('/')
      }
    }
  }
})

app.post('/reg', async (req, res, next) => {
    let err = null 
    const {email, password, rePassword} = req.body
    if (!email || !password || !rePassword) {
      err = 'empty fields'  
      return res.render('reg', {error:err, email:email, password:password, rePassword:rePassword})
    }
    else if (!validator.isEmail(email)) {
      err = 'email is not valid'
      return res.render('reg', {error:err, email:email, password:password, rePassword:rePassword})
    }else if (password.length < 6) {
      err = 'password less then 6 symbols'
      return res.render('reg', {error:err, email:email, password:password, rePassword:rePassword})
    }
    else if (password != rePassword) {
      err = 'password is not confirm'
      return res.render('reg', {error:err, email:email, password:password, rePassword:rePassword})
    }
    else {
      err = 'registration succesfully'
      const hashPassword = await bcrypt.hash(password, 10)
      const connection = await pool.getConnection()
      await connection.execute('INSERT INTO users (email, password, role) VALUES(?,?,0)', [email, hashPassword])
      connection.release()
      return res.redirect('/auth')
    }
})

app.post('/add', async (req, res) => {
  const {title, price} = req.body
  
    let uploadPath = '/img/' + Date.now() + Math.random() + path.extname(req.files.photo.name)
       
    const connection = await pool.getConnection()
  await connection.execute('INSERT INTO product (img, title, price)  VALUES (?,?,?)', [uploadPath, title, price])
  connection.release()

  uploadPath = __dirname + '/public' + uploadPath

  req.files.photo.mv(uploadPath);
  res.redirect('/')
})

app.post('/del', async (req, res) => {
  const {del_id} = req.body
  const connection = await pool.getConnection()
  const [products] = await connection.execute('SELECT * FROM product WHERE id = ?', [del_id])
  const product = products[0]
  const delPath = __dirname + '/public' + product.img
  await fs.unlink(delPath, () => {})
await connection.execute('DELETE FROM product WHERE id = ?', [del_id])
  connection.release()
res.redirect('/')
})

app.post('/update', async (req, res) => {
  const {title, price, update_id} = req.body
  const connection = await pool.getConnection()
  if (typeof req.files != 'undefined' && req.files) {
         const [products] = await connection.execute('SELECT * FROM product WHERE id = ?', [update_id])
      const product = products[0]
    fs.unlink(__dirname+'/public'+product.img, ()=>{})
    let img = '/img/' + Date.now() + Math.random() + path.extname(req.files.photo.name)
      await connection.execute('UPDATE product SET title = ?, img = ?, price = ? WHERE id = ?', [title, img, price, update_id])
      img = __dirname + '/public' + img
      req.files.photo.mv(img)
  }else {
      await connection.execute('UPDATE product SET title = ?, price = ? WHERE id = ?', [title, price, update_id])
  }
  connection.release()
  res.redirect('/')
})

app.listen(3000, () => {
  console.log('Server running')
})